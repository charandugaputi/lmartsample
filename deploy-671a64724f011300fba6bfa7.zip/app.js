let cart = [];
let total = 0;
let isLoggedIn = false; // Track login state

// Sample product data
const products = [
    { name: 'Apples', price: 150, category: 'fruits', available: true },
    { name: 'Bananas', price: 80, category: 'fruits', available: true },
    { name: 'Oranges', price: 150, category: 'fruits', available: true },
    { name: 'Watermelon', price: 150, category: 'fruits', available: false },
    { name: 'Grapes', price: 150, category: 'fruits', available: true },
    { name: 'Carrots', price: 60, category: 'vegetables', available: true },
    { name: 'Beans', price: 60, category: 'vegetables', available: true },
    { name: 'Beetroot', price: 60, category: 'vegetables', available: false },
    { name: 'Tomatoes', price: 60, category: 'vegetables', available: true },
    { name: 'Pickle Achar', price: 120, category: 'pickles', available: true },
    { name: 'Mango Pickle', price: 130, category: 'pickles', available: true }
];

// Display products based on selected category and availability
const displayProducts = (category = '') => {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';
    products.forEach(product => {
        const div = document.createElement('div');
        div.className = 'product';

        // Check for availability and category
        if ((!category || product.category === category) && product.available) {
            div.innerHTML = `
                <h3>${product.name}</h3>
                <p>Price: ₹${product.price}/kg</p>
                <label>Quantity (grams): <input type="number" id="quantity-${product.name}" min="100" step="100" value="100"></label>
                <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
                <button onclick="viewProduct('${product.name}')">View</button>
            `;
        } else if (product.category === category || !category) {
            div.innerHTML = `
                <h3>${product.name}</h3>
                <p style="color:red;">Not Available</p>
            `;
        }
        productList.appendChild(div);
    });
};

// Add product to cart and calculate total based on grams
const addToCart = (name, price) => {
    const quantityInput = document.getElementById(`quantity-${name}`).value;
    const quantityInKg = quantityInput / 1000;
    const itemTotal = price * quantityInKg;

    cart.push({ name, price, quantity: quantityInput });
    total += itemTotal;
    updateCart();
};

// Update cart display with selected items and total price
const updateCart = () => {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - ${item.quantity}g - ₹${(item.price * (item.quantity / 1000)).toFixed(2)}`;
        cartItems.appendChild(li);
    });
    document.getElementById('total-price').textContent = `Total: ₹${total.toFixed(2)}`;
};

// Category filter
const filterByCategory = () => {
    const selectedCategory = document.getElementById('category-select').value;
    displayProducts(selectedCategory);
};

// Checkout modal display
const checkout = () => {
    if (!isLoggedIn) {
        alert("Please log in to place an order.");
        return;
    }
    document.getElementById('checkout-modal').style.display = 'flex';
};

// Finalize checkout with validation (redirect to WhatsApp)
const finalizeCheckout = () => {
    const name = sanitizeInput(document.getElementById('name').value);
    const email = sanitizeInput(document.getElementById('email').value);
    const phone = sanitizeInput(document.getElementById('phone').value);
    const address = sanitizeInput(document.getElementById('address').value);

    // Validate address for Suraram
    if (!address.toLowerCase().includes("suraram")) {
        alert("Please enter a complete address located in Suraram, Hyderabad.");
        return;
    }

    if (!name || !email || !phone || !address) {
        alert("Please fill in all fields.");
        return;
    }

    const orderDetails = `Name: ${name}\nPhone: ${phone}\nAddress: ${address}\nProducts: ${JSON.stringify(cart)}`;
    const whatsappMessage = `Hello! I'd like to place an order:\n${orderDetails}`;
    const whatsappUrl = `https://wa.me/91${phone}?text=${encodeURIComponent(whatsappMessage)}`;

    window.open(whatsappUrl, '_blank');
    clearCart();
};

// Clear cart after checkout
const clearCart = () => {
    cart = [];
    total = 0;
    updateCart();
    closeModal('checkout-modal');
};

// View product details in modal
const viewProduct = name => {
    const product = products.find(p => p.name === name);
    const modalContent = document.querySelector('#product-detail-modal .modal-content');
    modalContent.innerHTML = `
        <h3>${product.name}</h3>
        <p>Price: ₹${product.price}/kg</p>
        <p>Category: ${product.category}</p>
        <p>${product.available ? 'Available' : 'Not Available'}</p>
        <button onclick="closeModal('product-detail-modal')">Close</button>
    `;
    document.getElementById('product-detail-modal').style.display = 'flex';
};

// Search functionality
const searchProducts = () => {
    const query = document.getElementById('search-bar').value.toLowerCase();
    const filteredProducts = products.filter(product => product.name.toLowerCase().includes(query));
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';

    filteredProducts.forEach(product => {
        const div = document.createElement('div');
        div.className = 'product';
        if (product.available) {
            div.innerHTML = `
                <h3>${product.name}</h3>
                <p>Price: ₹${product.price}/kg</p>
                <label>Quantity (grams): <input type="number" id="quantity-${product.name}" min="100" step="100" value="100"></label>
                <button onclick="addToCart('${product.name}', ${product.price})">Add to Cart</button>
                <button onclick="viewProduct('${product.name}')">View</button>
            `;
        } else {
            div.innerHTML = `
                <h3>${product.name}</h3>
                <p style="color:red;">Not Available</p>
            `;
        }
        productList.appendChild(div);
    });
};

// Modal control functions
const closeModal = modalId => {
    document.getElementById(modalId).style.display = 'none';
};

// Sanitize user input to prevent XSS
const sanitizeInput = input => {
    return input.replace(/</g, "&lt;").replace(/>/g, "&gt;");
};

// Signup functionality
const signup = () => {
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;

    if (!name || !email || !password) {
        alert("Please fill in all fields.");
        return;
    }

    // In a real application, you would send this data to the server
    alert("Signup successful!");
    closeModal('signup-modal');
};

// Login functionality
const login = () => {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;

    if (!email || !password) {
        alert("Please fill in all fields.");
        return;
    }

    // Here we simulate a successful login
    isLoggedIn = true; // Set login state to true
    alert("Login successful!");
    closeModal('login-modal');
};

// Show modals
const showLoginModal = () => {
    document.getElementById('login-modal').style.display = 'flex';
};

const showSignupModal = () => {
    document.getElementById('signup-modal').style.display = 'flex';
};

// Initialize product display on page load
document.addEventListener('DOMContentLoaded', () => displayProducts());
